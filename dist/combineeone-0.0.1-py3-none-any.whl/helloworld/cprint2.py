def say_hello2(name=None):
    if name == None:
        return 'Hello, World2!'
    else:
        return f'Hello, {name}2!'